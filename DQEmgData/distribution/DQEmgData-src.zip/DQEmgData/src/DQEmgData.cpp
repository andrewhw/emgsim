/*
 * Copyright (c) 2002
 * All rights reserved.
 *
 * Original Authors:
 *      Daniel Stashuk          stashuk@pami.uwaterloo.ca
 *      Andrew Hamilton-Wright  andrewhw@ieee.org
 *
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. The original authors must be made aware of, and party to, any
 *    redistribution of this source code.
 * 2. Any updates or modification to this code shall be made with
 *    the full knowledge of the original authors, so that all
 *    software using this file format may remain interoperable.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS, CONTRIBUTORS OR THE UNIVERSITY OF
 * WATERLOO BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

/**
 ** Handle the reading and writing of files in the DQEMG Data File
 ** Format.
 **
 ** $Id: DQEmgData.cpp,v 1.52 2006/11/09 23:26:45 andrew Exp $
 **/

#include "os_defs.h"

#ifndef MAKEDEPEND
# include       <stdio.h>
# include       <string.h>
# include       <math.h>
# include       <errno.h>
# include       <sys/types.h>
# include       <sys/stat.h>
# ifndef        OS_WINDOWS_NT
#   include     <unistd.h>
# else
#   include     <io.h>
# endif
# include       <fcntl.h>
# include       <stdlib.h>
#endif

#include "julian.h"
#include "DQEmgData.h"

/* uncomment this to add some data to test "forward compatibility" */
// #define      FORWARD_COMPAT_TEST
// #define	RESTRICT_TO_BASE_VERSION

char *DQEmgData::FILE_TAG = "DQEMG";
int   DQEmgData::FILE_TAG_LEN = 5;
char version_ = 0x01; //MABD, when we read old studies, version_= 0x00

static int sMaxError_ = (-1);
static char *sErrors_[] = {
	"no error",
	"errno-error",
	"not a DQEMG file",
	"incompatible version",
	"data overflow for type",
	"bad encoding",
	"unknown encoding",
	NULL
};

/* context class to hold temporary calculations */
class DQEmgDataContext
{
public:
    off_t headerChannelOffsetLocation_;
    off_t *dataOffsets_;

public:
    DQEmgDataContext();
    ~DQEmgDataContext();
};

DQEmgDataContext::DQEmgDataContext()
{
    memset(this, 0, sizeof(DQEmgDataContext));
}

DQEmgDataContext::~DQEmgDataContext()
{
}

/*
 * Create a whole new data set
 */
DQEmgData::DQEmgData()
{
    memset(this, 0, sizeof(DQEmgData));
    context_ = new DQEmgDataContext();

    setContractionDefaultValues_();
}

DQEmgData::DQEmgData(
	const char *vendorId,
	time_t acquisitionTime,
	const char *operatorDescription,
	const char *subjectDescription,
	const char *subjectID,
	int yearOfBirth,
	int monthOfBirth,
	int dayOfBirth,
	unsigned int age,
	Gender subjectGender,
	const char *muscleDescription,
	Side muscleSide,
	const char *generalDescription
    )
{
    memset(this, 0, sizeof(DQEmgData));
    context_ = new DQEmgDataContext();

    setContractionDefaultValues_();

    setVendorIdentifier(vendorId);
    setAcquisitionTime(acquisitionTime);
    setOperatorDescription(operatorDescription);

    setSubjectDescription(subjectDescription);
    setSubjectAge(age);
    setSubjectDateOfBirth(yearOfBirth, monthOfBirth, dayOfBirth);
    setSubjectGender(subjectGender);
    setSubjectID(subjectID);

    setMuscleDescription(muscleDescription);
    setMuscleSide(muscleSide);

    setGeneralDescription(generalDescription);
}


DQEmgData::DQEmgData(
	const char *vendorId,
	time_t acquisitionTime,
	const char *operatorDescription,
	const char *subjectDescription,
	const char *muscleDescription,
	const char *generalDescription
    )
{
    memset(this, 0, sizeof(DQEmgData));
    context_ = new DQEmgDataContext();

    setContractionDefaultValues_();

    setVendorIdentifier(vendorId);
    setAcquisitionTime(acquisitionTime);
    setOperatorDescription(operatorDescription);
    setSubjectDescription(subjectDescription);
    setMuscleDescription(muscleDescription);
    setGeneralDescription(generalDescription);

}

DQEmgData::DQEmgData(const char *vendorId)
{
    memset(this, 0, sizeof(DQEmgData));
    context_ = new DQEmgDataContext();

    setContractionDefaultValues_();

    setVendorIdentifier(vendorId);
}

/*
 * destroy one of these objects
 */
DQEmgData::~DQEmgData()
{
    clear();
}

/**
 ** This is called from the constructor functions
 **/
void DQEmgData::setContractionDefaultValues_()
{
    acquisitionTime_ = time(NULL);
    subjectJulianDateOfBirth_ = 0;
    subjectAge_ = 0;
    subjectGender_ = 0;
    studyFlags_ = 0;
    muscleSide_ = 0;
    contractionType_ = DQEmgData::NOT_DEFINED;
    cmapStored_ = 0;
    mSmupStored_ = 0;
	numCmapStored_ = 0; //ABDSAVE
	numAutoSmupStored_ =0;//mauto

	/*MarzTest*/
	indexOfFirstSmup_ = 1;
	indexOfSecondSmup_ = 1;
	indexOfThirdSmup_ = 1;
	indexOfBaseSmup_ = 1;
	FreqOfFirstSmup_ = 0;
	FreqOfSecondSmup_ = 0;
	FreqOfThirdSmup_ = 0;
	FreqOfBaseSmup_ = 0;
	/*MarzTest*/
}

void DQEmgData::clear()
{
    unsigned long i;

    if (context_ != NULL) {
	if (context_->dataOffsets_ != NULL) {
	    delete [] context_->dataOffsets_;
	}
	delete context_;
	context_ = NULL;
    }

    if ( filename_ != NULL) {
	delete [] filename_;
	filename_ = NULL;
    }

    if ( vendorIdentifier_ != NULL) {
	delete [] vendorIdentifier_;
	vendorIdentifier_ = NULL;
    }

    if ( operatorDescription_ != NULL) {
	delete [] operatorDescription_;
	operatorDescription_ = NULL;
    }

    if ( subjectDescription_ != NULL) {
	delete [] subjectDescription_;
	subjectDescription_ = NULL;
    }

    if ( subjectID_ != NULL) {
	delete [] subjectID_;
	subjectID_ = NULL;
    }

    if ( muscleDescription_ != NULL) {
	delete [] muscleDescription_;
	muscleDescription_ = NULL;
    }

    if ( generalDescription_ != NULL) {
	delete [] generalDescription_;
	generalDescription_ = NULL;
    }

    if (data_ != NULL) {
	for (i = 0; i < numChannels_; i++) {
	    delete data_[i];
	}
	delete [] data_;
	data_ = NULL;
    }
}


/*
 *      Create a Channel object
 */
DQEmgChannelData::DQEmgChannelData()
{
    memset(this, 0, sizeof(DQEmgChannelData));
    encoding_ = (int) SHORT;

    setChannelDefaultValues_();
}

DQEmgChannelData::DQEmgChannelData(
	unsigned char channelNumber,
	unsigned long highPassCutoff,
	unsigned long lowPassCutoff,
	const char *channelDescription
    )
{
    memset(this, 0, sizeof(DQEmgChannelData));
    encoding_ = (int) SHORT;

    setChannelDefaultValues_();

    setChannelNumber(channelNumber);
    setHighPassCutoff(highPassCutoff);
    setLowPassCutoff(lowPassCutoff);
    setChannelDescription(channelDescription);
}

/*
 * destroy one of these objects
 */
DQEmgChannelData::~DQEmgChannelData()
{
    if ( channelDescription_ != NULL) {
	delete [] channelDescription_;
	channelDescription_ = NULL;
    }

    if ( unitDescription_ != NULL) {
	delete [] unitDescription_;
	unitDescription_ = NULL;
    }

    if ( dataShortSample_ != NULL)
	delete [] dataShortSample_;

    if ( dataLongSample_ != NULL)
	delete [] dataLongSample_;
}

void DQEmgChannelData::setChannelDefaultValues_()
{
    negativePeakArea_ = 0;
    peakToPeakAmplitude_ = 0;
    negativePeakAmplitude_ = 0;
    onsetPos_ = 0;
    positivePeakPos_ = 0;
    endPos_ = 0;
	index_ = 0;

    duration_ = 0;
    negativePeakDuration_ = 0;
    area_ = 0;
    peakOnsetPos_ = 0;
    peakEndPos_ = 0;

    isValid_ = 0;   // Default is false
    numSmupsInAvg_ = 0;
}

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////////  Channel  ////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

int DQEmgChannelData::convertDataToShort_()
{
    unsigned long i;

    dataShortSample_ = new short[numSamples_];

    for (i = 0; i < numSamples_; i++) {
	if (dataLongSample_[i] >= USHRT_MAX) {
	    return 0;
	}
	dataShortSample_[i] = (short) dataLongSample_[i];
    }

    return 1;
}
int DQEmgChannelData::convertDataToLong_()
{
    unsigned long i;

    dataLongSample_ = new long[numSamples_];

    for (i = 0; i < numSamples_; i++) {
	dataLongSample_[i] = (long) dataShortSample_[i];
    }

    return 1;
}

short *DQEmgChannelData::getDataAsShort(
	unsigned long *numSamples,
	float *samplingRate,
	float *scale
    )
{
    *numSamples = numSamples_;
    *scale = scale_;
    *samplingRate = samplingRate_;
    if (dataShortSample_ == NULL) {
	if ( ! convertDataToShort_() ) {
	    return NULL;
	}
    }
    return dataShortSample_;
}

long *DQEmgChannelData::getDataAsLong(
	unsigned long *numSamples,
	float *samplingRate,
	float *scale
    )
{
    *numSamples = numSamples_;
    *scale = scale_;
    *samplingRate = samplingRate_;
    if (dataLongSample_ == NULL) {
	if ( ! convertDataToLong_() ) {
	    return NULL;
	}
    }
    return dataLongSample_;
}

void DQEmgChannelData::deleteOldData_()
{
    if (dataShortSample_ != NULL) {
	delete [] dataShortSample_;
    }
    if (dataLongSample_ != NULL) {
	delete [] dataLongSample_;
    }
    numSamples_ = 0;
}

int DQEmgChannelData::setData(
	unsigned long numSamples,
	short *data,
	float samplingRate,
	const char *unitDescription,
	float scale
    )
{
    deleteOldData_();
    numSamples_ = numSamples;
    dataShortSample_ = new short[numSamples_];
    memcpy(dataShortSample_, data, numSamples_ * sizeof(short));

    setUnitDescription_(unitDescription);
    samplingRate_ = samplingRate;
    scale_ = scale;

    return 1;
}

int DQEmgChannelData::setData(
	unsigned long numSamples,
	float *data,
	float samplingRate,
	const char *unitDescription,
	int encodingWidth,
	long maxUnscaledValue
    )
{
    unsigned long i;
    float absData, maxAbsValue = 0;
    double scaleRequired;

    deleteOldData_();

    if ( ! setEncoding(
		(DQEmgChannelData::Encoding)(
			(encoding_ & 0xFF00) | encodingWidth)
	    ) )
	return 0;

    if (encodingWidth == 2) {
	maxUnscaledValue = SHRT_MAX;
    } else if (encodingWidth == 4){
	maxUnscaledValue = LONG_MAX;
    } else {
	return 0;
    }

    for (i = 0; i < numSamples; i++) {
	absData = (float) fabs(data[i]);
	if (maxAbsValue < absData)
	    maxAbsValue = absData;
    }

    /**
     * by definition the scale we require is (the inverse of)
     * that which will adjust the maximum absolude value so that
     * it will be the maximum unscaled value
     */
    scaleRequired = 1.0 / (maxAbsValue / maxUnscaledValue);

    if (encodingWidth == 2) {
	dataShortSample_ = new short[numSamples_];
	memcpy(dataShortSample_, data, numSamples_ * sizeof(short));
	for (i = 0; i < numSamples; i++) {
	    dataShortSample_[i] = (short)
	    		((double) data[i] / scaleRequired);
	}
	
    } else {
	dataLongSample_ = new long[numSamples_];
	memcpy(dataLongSample_, data, numSamples_ * sizeof(long));
	for (i = 0; i < numSamples; i++) {
	    dataLongSample_[i] = (long)
	    		((double) data[i] / scaleRequired);
	}
    }

    numSamples_ = numSamples;
    setUnitDescription_(unitDescription);
    samplingRate_ = samplingRate;
    scale_ = (float) scaleRequired;

    return 1;
}


int DQEmgChannelData::setData(
	unsigned long numSamples,
	long *data,
	float samplingRate,
	const char *unitDescription,
	float scale
    )
{
    deleteOldData_();
    numSamples_ = numSamples;
    dataLongSample_ = new long[numSamples_];
    memcpy(dataLongSample_, data, numSamples_ * sizeof(long));

    setUnitDescription_(unitDescription);
    samplingRate_ = samplingRate;
    scale_ = scale;

    return 1;
}

int DQEmgChannelData::setEncoding(DQEmgChannelData::Encoding encoding)
{
    if (((int) encoding) == 0x0002 || ((int) encoding) == 0x0004) {
	encoding_ = encoding;
	return 1;
    }
    return 0;
}
int DQEmgChannelData::getEncodingFlags() const
{
    return ((encoding_ & 0xFF00) >> 8);
}
int DQEmgChannelData::getEncodingWidth() const
{
    return (encoding_ & 0x00FF);
}

void DQEmgChannelData::setChannelNumber(unsigned char channelNumber)
{
    channelNumber_ = channelNumber;
}
unsigned char DQEmgChannelData::getChannelNumber() const
{
    return channelNumber_;
}

unsigned long DQEmgChannelData::getHighPassCutoff() const
{
    return hipassCutoff_;
}
void DQEmgChannelData::setHighPassCutoff(unsigned long newFreq)
{
    hipassCutoff_ = newFreq;
}
unsigned long DQEmgChannelData::getLowPassCutoff() const
{
    return lopassCutoff_;
}
void DQEmgChannelData::setLowPassCutoff(unsigned long newFreq)
{
    lopassCutoff_ = newFreq;
}

unsigned long DQEmgChannelData::getElapsedTime() const
{
    return elapsedTime_;
}
void DQEmgChannelData::setElapsedTime(unsigned long newTime)
{
    elapsedTime_ = newTime;
}

void DQEmgChannelData::setEvokedResponseNegativePeakArea(float negativePeakArea)
{
    negativePeakArea_ = negativePeakArea;
}

float DQEmgChannelData::getEvokedResponseNegativePeakArea() const
{
    return negativePeakArea_ ;
}

void DQEmgChannelData::setEvokedResponsePeakToPeakAmplitude(float peakToPeakAmplitude)
{
    peakToPeakAmplitude_ = peakToPeakAmplitude;
}

float DQEmgChannelData::getEvokedResponsePeakToPeakAmplitude() const
{
    return  peakToPeakAmplitude_ ;
}

void DQEmgChannelData::setEvokedResponseNegativePeakAmplitude(float negativePeakAmplitude)
{
    negativePeakAmplitude_ = negativePeakAmplitude;
}

float DQEmgChannelData::getEvokedResponseNegativePeakAmplitude() const
{
    return negativePeakAmplitude_ ;
}

void DQEmgChannelData::setEvokedResponseValidity(bool Valid)
{
    isValid_= Valid;
}

bool DQEmgChannelData::getEvokedResponseValidity() const
{
    return isValid_;
}

void DQEmgChannelData::setNumberOfSmupsInAvg(int NumSmups)
{
    numSmupsInAvg_ = NumSmups;
}

int DQEmgChannelData::getNumberOfSmupsInAvg() const
{
    return numSmupsInAvg_;
}

unsigned long DQEmgChannelData::getNumberOfSamples() const
{
    return numSamples_;
}

// Additional statistics used for evoked responses 
void DQEmgChannelData::setEvokedResponseDuration(float duration)
{
    duration_ = duration;
}
float DQEmgChannelData::getEvokedResponseDuration() const
{
    return duration_;
}

void DQEmgChannelData::setEvokedResponseNegativePeakDuration(float negativePeakDuration)
{
    negativePeakDuration_ = negativePeakDuration;
}

float DQEmgChannelData::getEvokedResponseNegativePeakDuration() const
{
    return negativePeakDuration_;
}

void DQEmgChannelData::setEvokedResponseArea(float area)
{
    area_ = area;
}

float DQEmgChannelData::getEvokedResponseArea() const
{
    return area_;
}

void DQEmgChannelData::setEvokedResponsePeakOnsetPos(short peakOnsetPos)
{
    peakOnsetPos_ = peakOnsetPos;
}

short DQEmgChannelData::getEvokedResponsePeakOnsetPos() const
{
    return peakOnsetPos_;
}

void DQEmgChannelData::setEvokedResponsePeakEndPos(short peakEndPos)
{
    peakEndPos_ = peakEndPos;
}

short DQEmgChannelData::getEvokedResponsePeakEndPos() const
{
    return peakEndPos_;
}

float DQEmgChannelData::getSamplingRate() const
{
    return samplingRate_;
}


float DQEmgChannelData::getScaleFactor() const
{
    return scale_;
}

const char * DQEmgChannelData::getChannelDescription() const
{
    return channelDescription_;
}
void DQEmgChannelData::setChannelDescription(
	const char *newDescription
    )
{
    if (channelDescription_ != NULL) {
	delete [] channelDescription_;
    }

    if (newDescription != NULL) {
	channelDescription_ = new char[ strlen(newDescription) + 1 ];
	strcpy(channelDescription_, newDescription);
	
    } else {
	channelDescription_ = NULL;
    }

}

const char * DQEmgChannelData::getUnitDescription() const
{
    return unitDescription_;
}
void DQEmgChannelData::setUnitDescription_(
	const char *newDescription
    )
{
    if (unitDescription_ != NULL) {
	delete [] unitDescription_;
    }

    if (newDescription != NULL) {
	unitDescription_ = new char[ strlen(newDescription) + 1 ];
	strcpy(unitDescription_, newDescription);
	
    } else {
	unitDescription_ = NULL;
    }
}


////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////////  Data  ///////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////


const char *DQEmgData::getVendorIdentifier() const
{
    return vendorIdentifier_;
}
int DQEmgData::setVendorIdentifier(const char *newId)
{
    if (vendorIdentifier_ != NULL) {
	delete [] vendorIdentifier_;
	vendorIdentifier_ = NULL;
    }

    if (newId == NULL)
	return 0;

    if (strlen(newId) <= MAX_VENDOR_ID_LENGTH) {
	/**
	 * the entire string will fit within the specified
	 * storage length, so save the whole thing
	 */
	vendorIdentifier_ = new char[ strlen(newId) + 1 ];
	strcpy(vendorIdentifier_, newId);
	
    } else {
	/**
	 * the string is longer than the specified length
	 * so we create a buffer long enough for the specifier
	 * and copy the specified number of characters into
	 * the buffer
	 */
	vendorIdentifier_ = new char[ MAX_VENDOR_ID_LENGTH + 1];
	vendorIdentifier_[MAX_VENDOR_ID_LENGTH] = 0;
	memcpy(vendorIdentifier_, newId, MAX_VENDOR_ID_LENGTH);
    }

    return 1;
}

const char *DQEmgData::getOperatorDescription() const
{
    return operatorDescription_;
}
void DQEmgData::setOperatorDescription(const char *newDesc)
{
    if (operatorDescription_ != NULL) {
	delete [] operatorDescription_;
    }


    if (newDesc != NULL) {
	operatorDescription_ = new char[ strlen(newDesc) + 1 ];
	strcpy(operatorDescription_, newDesc);
	
    } else {
	operatorDescription_ = NULL;
    }
}

/** set all the subject info in one go */
void DQEmgData::setAllSubjectInformation(
	const char *description,
	const char *id,
	int yearOfBirth,
	int monthOfBirth,
	int dayOfBirth,
	unsigned int age,
	DQEmgData::Gender gender
    )
{
    setSubjectDescription(description);
    setSubjectID(id);
    setSubjectDateOfBirth(yearOfBirth, monthOfBirth, dayOfBirth);
    setSubjectAge(age);
    setSubjectGender(gender);
}

const char *DQEmgData::getSubjectDescription() const
{
    return subjectDescription_;
}
void DQEmgData::setSubjectDescription(const char *newDesc)
{
    if (subjectDescription_ != NULL) {
	delete [] subjectDescription_;
    }

    if (newDesc != NULL) {
	subjectDescription_ = new char[ strlen(newDesc) + 1 ];
	strcpy(subjectDescription_, newDesc);
	
    } else {
	subjectDescription_ = NULL;
    }
}

const char *DQEmgData::getSubjectID() const
{
    return subjectID_;
}
void DQEmgData::setSubjectID(const char *newID)
{
    if (subjectID_ != NULL) {
	delete [] subjectID_;
    }

    if (newID != NULL) {
	subjectID_ = new char[ strlen(newID) + 1 ];
	strcpy(subjectID_, newID);
	
    } else {
	subjectID_ = NULL;
    }
}

int DQEmgData::getSubjectDateOfBirth(
	unsigned long *year,
	unsigned long *month,
	unsigned long *day
    ) const
{
    return getGregorianDate(year, month, day,
	subjectJulianDateOfBirth_);
}
long DQEmgData::getSubjectJulianDateOfBirth() const
{
    return subjectJulianDateOfBirth_;
}
int DQEmgData::setSubjectDateOfBirth(
	int yearOfBirth,
	int monthOfBirth,
	int dayOfBirth
    )
{
    int status;
    status = getJulianDate(
	&subjectJulianDateOfBirth_,
	yearOfBirth, monthOfBirth, dayOfBirth);

    if ( ! status )
	subjectJulianDateOfBirth_ = 0;

    return status;
}

void DQEmgData::setSubjectAge(unsigned int age)
{
    subjectAge_ = age;
}

unsigned int DQEmgData::getSubjectAge()
{
    return subjectAge_;
}

int DQEmgData::getSubjectGender() const
{
    return (int) subjectGender_;
}
void DQEmgData::setSubjectGender(DQEmgData::Gender gender)
{
    subjectGender_ = (char) gender;
}

int DQEmgData::isCmapStored()
{
    return (int) cmapStored_;
}
void DQEmgData::setCmapStored(int isStored)
{
    cmapStored_ = isStored;
}
int DQEmgData::numCmapsStored() //ABD
{
	return numCmapStored_;
}
void DQEmgData::setNumCmapStored(int num) //ABD
{
	numCmapStored_ = num;
}
int DQEmgData::numAutoSmupStored() //mauto
{
	return numAutoSmupStored_;
}
void DQEmgData::setNumAutoSmupStored(int num) //mauto
{
	numAutoSmupStored_ = num;
}

/*MarzTest*/
void DQEmgData::setIndexOfFirstSmup(int index)   
{
	indexOfFirstSmup_ = index;
}
int DQEmgData::getIndexOfFirstSmup() 		 
{
	return indexOfFirstSmup_;
}
void DQEmgData::setIndexOfSecondSmup(int index)   
{
	indexOfSecondSmup_ = index;
}
int DQEmgData::getIndexOfSecondSmup() 		 
{
	return indexOfSecondSmup_;
}
void DQEmgData::setIndexOfThirdSmup(int index)   
{
	indexOfThirdSmup_ = index;
}
int DQEmgData::getIndexOfThirdSmup()		 
{
	return indexOfThirdSmup_;
}
void DQEmgData::setIndexOfBaseSmup(int index)   
{
	indexOfBaseSmup_ = index;
}
int DQEmgData::getIndexOfBaseSmup() 	 
{
	return indexOfBaseSmup_;
}


void DQEmgData::setFreqOfFirstSmup(float Freq)   
{
	FreqOfFirstSmup_ = Freq;
}
float DQEmgData::getFreqOfFirstSmup() 	 
{
	return FreqOfFirstSmup_;
}
void DQEmgData::setFreqOfSecondSmup(float Freq)   
{
	FreqOfSecondSmup_ = Freq;
}
float DQEmgData::getFreqOfSecondSmup() 		 
{
	return FreqOfSecondSmup_;
}
void DQEmgData::setFreqOfThirdSmup(float Freq)   
{
	FreqOfThirdSmup_ = Freq;
}
float DQEmgData::getFreqOfThirdSmup() 	 
{
	return FreqOfThirdSmup_;
}
void DQEmgData::setFreqOfBaseSmup(float Freq)   
{
	FreqOfBaseSmup_ = Freq;
}
float DQEmgData::getFreqOfBaseSmup() 		 
{
	return FreqOfBaseSmup_;
}
/*MarzTest*/
int DQEmgData::is_mSmupStored()
{
    return (int) mSmupStored_;
}
void DQEmgData::set_mSmupStored(int isStored)
{
    mSmupStored_ = isStored;
}

unsigned long DQEmgData::isNewOperator() const
{
    return (studyFlags_ & FLAG_NEW_OPERATOR) != 0;
}
void DQEmgData::setNewOperator(int newOperator)
{
    studyFlags_ = studyFlags_ & ~FLAG_NEW_OPERATOR;
    if (newOperator)
	studyFlags_ = studyFlags_ | FLAG_NEW_OPERATOR;
}

unsigned long DQEmgData::isNewPatient() const
{
    return (studyFlags_ & FLAG_NEW_PATIENT) != 0;
}

void DQEmgData::setNewPatient(int newPatient)
{
    studyFlags_ = studyFlags_ & ~FLAG_NEW_PATIENT;
    if (newPatient)
	studyFlags_ = studyFlags_ | FLAG_NEW_PATIENT;
}

unsigned long DQEmgData::isNewMuscle() const
{
    return (studyFlags_ & FLAG_NEW_MUSCLE) != 0;
}
void DQEmgData::setNewMuscle(int newMuscle)
{
    studyFlags_ = studyFlags_ & ~FLAG_NEW_MUSCLE;
    if (newMuscle)
	studyFlags_ = studyFlags_ | (FLAG_NEW_MUSCLE);
}

const char *DQEmgData::getMuscleDescription() const
{
    return muscleDescription_;
}
void DQEmgData::setMuscleDescription(const char *newDesc)
{
    if (muscleDescription_ != NULL) {
	delete [] muscleDescription_;
    }

    if (newDesc != NULL) {
	muscleDescription_ = new char[ strlen(newDesc) + 1 ];
	strcpy(muscleDescription_,newDesc);
	
    } else {
	muscleDescription_ = NULL;
    }
}

int DQEmgData::getMuscleSide() const
{
    return (int) muscleSide_;
}
void DQEmgData::setMuscleSide(DQEmgData::Side side)
{
    muscleSide_ = (char) side;
}

const char *DQEmgData::getGeneralDescription() const
{
    return generalDescription_;
}
void DQEmgData::setGeneralDescription(const char *newDesc)
{
    if (generalDescription_ != NULL) {
	delete [] generalDescription_;
    }

    if (newDesc != NULL) {
	generalDescription_ = new char[strlen(newDesc)+1];
	strcpy(generalDescription_,newDesc);
	
    } else {
	generalDescription_ = NULL;
    }
}

void DQEmgData::setFileName(const char *newName)
{
    if (filename_ != NULL) {
	delete [] filename_;
    }
    filename_  = new char[ strlen(newName) + 1 ];
    strcpy(filename_, newName);
}

const char *DQEmgData::getFileName() const
{
    return filename_;
}

time_t DQEmgData::getAcquisitionTime() const
{
    return acquisitionTime_;
}
void DQEmgData::setAcquisitionTime(time_t newTime)
{
    acquisitionTime_ = newTime;
}

unsigned char DQEmgData::getNumChannels() const
{
    return numChannels_;
}
int DQEmgData::addChannel(DQEmgChannelData *newChannel)
{
    DQEmgChannelData **oldList;
    unsigned long i;

    if (numChannels_ == 255)
	return 0;

    oldList = data_;

    data_ = new DQEmgChannelData *[ numChannels_ + 1 ];
    memset(data_, 0, sizeof(DQEmgChannelData *) * (numChannels_ + 1));

    /**
     * move over all the existing channels.  If there
     * are none, then numChannels will be zero, and the
     * loop will do nothing other than initialize i
     */
    for (i = 0; i < numChannels_; i++) {
	data_[i] = oldList[i];
    }
    data_[numChannels_++] = newChannel;

    if (oldList != NULL)
	delete [] oldList;

    return 1;
}
DQEmgChannelData *DQEmgData::getChannel(unsigned char index) const
{
    if (data_ != NULL) {
	if (index < numChannels_) {
	    return data_[index];
	}
    }

    return NULL;
}

void DQEmgData::setContractionType(Contraction contractionType)
{
    contractionType_ = (char)contractionType;
}
int  DQEmgData::getContractionType()
{
    return (int)contractionType_;
}
int DQEmgData::isEvoked()
{
    if (contractionType_== EVOKED)
	return true;
    else
	return false;
}

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////////  I/O  ////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

int DQEmgData::load(const char *filename)
{
    int fd, result;;

    setFileName(filename);
    fd = open(filename_,
#ifdef  OS_WINDOWS_NT
	O_RDONLY|O_BINARY,
#else
	O_RDONLY,
#endif
	0);
    if (fd < 0)
	return 0;

    result = load_(fd);

    result = (close(fd) >= 0) && result;

    return result;
}


int DQEmgData::store(const char *filename)
{
    int fd, result;;
    setFileName(filename);

    fd = open(filename_,
#ifdef  OS_WINDOWS_NT
	O_CREAT|O_TRUNC|O_WRONLY|O_BINARY,
#else
	O_CREAT|O_TRUNC|O_WRONLY,
#endif
	0666);
    if (fd < 0)
	return 0;

    result = store_(fd);

    result = (close(fd) >= 0) && result;

    return result;
}

int DQEmgData::loadContractionDataHeader_(int fd)
{
    char ibuf[MAX_VENDOR_ID_LENGTH + 1];
    char version;
    unsigned long i;
    off_t firstDataOffset = 0;
    off_t curOffset;
    int s;

    /* read in the DQEMG tag */
    s = read(fd, ibuf, FILE_TAG_LEN);
    if (s != FILE_TAG_LEN) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (memcmp(ibuf, FILE_TAG, FILE_TAG_LEN) != 0) {
	setError(ERR_NOT_DQEMG_FILE);
	return 0;
    }

    /**
     * set up default values for all extended (optional)
     * header values
     */
    setContractionDefaultValues_();


    /* read out vendor id */
    s = read(fd, ibuf, MAX_VENDOR_ID_LENGTH);
    if (s != MAX_VENDOR_ID_LENGTH) {
	setError(ERR_ERRNO);
	return 0;
    }
    ibuf[MAX_VENDOR_ID_LENGTH] = 0;
    i = MAX_VENDOR_ID_LENGTH - 1;
    while (i >= 0 && ibuf[i] == ' ') {
	ibuf[i] = 0;
	i--;
    }
    setVendorIdentifier(ibuf);


    /* acquisition time */
    s = read(fd, &acquisitionTime_, sizeof(acquisitionTime_));
    if (s != sizeof(acquisitionTime_)) {
	setError(ERR_ERRNO);
	return 0;
    }


    /* file version */
    s = read(fd, &version, sizeof(version));
    if (s != sizeof(version)) {
	setError(ERR_ERRNO);
	return 0;
    }

    version_ = version; //MABD


    //if (version_!= 0x00 ) {
//	if (version_!= 0x00 && version_!= 0x01) {//MABD
//	setError(ERR_INCOMPATIBLE_VERSION);
//	return 0;
//    }

    /* num channels */
    s = read(fd, &numChannels_, sizeof(numChannels_));
    if (s != sizeof(numChannels_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    if (numChannels_ > 0) {
	/**
	 * load the offsets into the structure in context
	 */
	context_->dataOffsets_ = new off_t[numChannels_];
	
	s = read(fd, context_->dataOffsets_,
		sizeof(off_t) * numChannels_);
	if (s != (int) (sizeof(off_t) * numChannels_)) {
	    setError(ERR_ERRNO);
	    return 0;
	}
	
	firstDataOffset = context_->dataOffsets_[0];
	for (i = 1; i < numChannels_; i++) {
	    if (firstDataOffset > context_->dataOffsets_[i])
		firstDataOffset = context_->dataOffsets_[i];
	}
    } else {
	/**
	 * if there were no channels, we stored at least one
	 * data offset to set up the firstDataOffset variable
	 */
	off_t tmp;

	s = read(fd, &tmp, sizeof(off_t));
	if (s != (int) (sizeof(off_t))) {
	    setError(ERR_ERRNO);
	    return 0;
	}

	firstDataOffset = tmp;
    }

    if ( ! loadVariableStringValue_(fd, &operatorDescription_, this) )
	return 0;

    if ( ! loadVariableStringValue_(fd, &subjectDescription_, this) )
	return 0;

    if ( ! loadVariableStringValue_(fd, &muscleDescription_, this) )
	return 0;

    if ( ! loadVariableStringValue_(fd, &generalDescription_, this) )
	return 0;

    /**
     * The information from this point on is not guaranteed to be
     * in all files.  We therefore check the offset at each
     * step to be sure that we have not exceeded the header length.
     *
     * Default values are provided at the top of the function so
     * we already know these fields are populated with a sensible value
     *
     * Note that although these values are "optional", they are in
     * a fixed order, so for later values to be present, earlier
     * values must exist
     */

    /* study flags */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    s = read(fd, &studyFlags_, sizeof(studyFlags_));
    if (s != sizeof(studyFlags_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* subject date of birth */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    s = read(fd,
	&subjectJulianDateOfBirth_,
	sizeof(subjectJulianDateOfBirth_));
    if (s != sizeof(subjectJulianDateOfBirth_)) {
	setError(ERR_ERRNO);
	return 0;
    }


    /* subject gender */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    s = read(fd, &subjectGender_, sizeof(subjectGender_));
    if (s != sizeof(subjectGender_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* muscle laterality */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    s = read(fd, &muscleSide_, sizeof(muscleSide_));
    if (s != sizeof(muscleSide_)) {
	setError(ERR_ERRNO);
	return 0;
    }



    /* Contraction Type */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    s = read(fd, &contractionType_, sizeof(contractionType_));
    if (s != sizeof(contractionType_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* subject ID */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    if ( ! loadVariableStringValue_(fd, &subjectID_, this) )
	return 0;

    // Waveforms are stored in the following order:
    // 1)  Cmap - cmapStored_
    // 2)  mSmup - mSmupStored_
    // 3)  Smups
	// 4)  Cmaps - Only for new versions

    // If the CMAP or mSMUP flag is 0, then it was not stored
    // These 2 flags, along with NumChannels, determine how many
    // SMUP's are in the mSMUP

    /* CMAP Stored Flag */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    s = read(fd, &cmapStored_, sizeof(cmapStored_));
    if (s != sizeof(cmapStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* mSMUP Stored Flag */
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    if (curOffset >= firstDataOffset)   goto END;
    s = read(fd, &mSmupStored_, sizeof(mSmupStored_));
    if (s != sizeof(mSmupStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }
    
    // Read back subject age instead of date of birth
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    s = read(fd,
	&subjectAge_,
	sizeof(subjectAge_));
    if (s != sizeof(subjectAge_)) {
	setError(ERR_ERRNO);
	return 0;
    }
	
	// Read the number of stored cmaps    //ABDSAVE
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    s = read(fd,
	&numCmapStored_,
	sizeof(numCmapStored_));
    if (s != sizeof(numCmapStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }

	// Read the number of stored cmaps    //mauto
    curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
	setError(ERR_ERRNO);
	return 0;
    }
    s = read(fd,
	&numAutoSmupStored_,
	sizeof(numAutoSmupStored_));
    if (s != sizeof(numAutoSmupStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }

/*MarzTest*/
	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
    s = read(fd, &indexOfFirstSmup_, sizeof(indexOfFirstSmup_));
    if (s != sizeof(indexOfFirstSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }

	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
    s = read(fd, &indexOfSecondSmup_, sizeof(indexOfSecondSmup_));
    if (s != sizeof(indexOfSecondSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }

	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
    s = read(fd, &indexOfThirdSmup_, sizeof(indexOfThirdSmup_));
	if (s != sizeof(indexOfThirdSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }

	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
    s = read(fd, &indexOfBaseSmup_, sizeof(indexOfBaseSmup_));
	if (s != sizeof(indexOfBaseSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }

	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
    s = read(fd, &FreqOfFirstSmup_, sizeof(FreqOfFirstSmup_));
	if (s != sizeof(FreqOfFirstSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }

	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
    s = read(fd, &FreqOfSecondSmup_, sizeof(FreqOfSecondSmup_));
	if (s != sizeof(FreqOfSecondSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }

	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
    s = read(fd, &FreqOfThirdSmup_, sizeof(FreqOfThirdSmup_));
	if (s != sizeof(FreqOfThirdSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }

	curOffset = lseek(fd, 0, SEEK_CUR);
    if (curOffset < 0) {
		setError(ERR_ERRNO);
		return 0;
    }
	s = read(fd, &FreqOfBaseSmup_, sizeof(FreqOfBaseSmup_));
	if (s != sizeof(FreqOfBaseSmup_)) {
		setError(ERR_ERRNO);
		return 0;
    }
/*MarzTest*/



END:
    /* return success */
    return 1;
}

int DQEmgData::storeContractionDataHeader_(int fd)
{
    char obuf[MAX_VENDOR_ID_LENGTH];
    char version;
    int s;
    unsigned long i;

    /* the only file version we support for now */
    //version = 0x00;
	version = version_; //MABD
    
	/* write out the DQEMG tag */
    s = write(fd, FILE_TAG, FILE_TAG_LEN);
    if (s != FILE_TAG_LEN) {
	setError(ERR_ERRNO);
	return 0;
    }


    /* write out vendor id */
    for (i = 0; i < MAX_VENDOR_ID_LENGTH && vendorIdentifier_[i]; i++) {
	obuf[i] = vendorIdentifier_[i];
    }
    while (i < MAX_VENDOR_ID_LENGTH) {
	obuf[i++] = ' ';
    }
    s = write(fd, obuf, MAX_VENDOR_ID_LENGTH);
    if (s != MAX_VENDOR_ID_LENGTH) {
	setError(ERR_ERRNO);
	return 0;
    }


    /* time of acquisition */
    s = write(fd, &acquisitionTime_, sizeof(acquisitionTime_));
    if (s != sizeof(acquisitionTime_)) {
	setError(ERR_ERRNO);
	return 0;
    }


    /* file version */
    s = write(fd, &version, sizeof(version));
    if (s != sizeof(version)) {
	setError(ERR_ERRNO);
	return 0;
    }


    /* num channels */
    s = write(fd, &numChannels_, sizeof(numChannels_));
    if (s != sizeof(numChannels_)) {
	setError(ERR_ERRNO);
	return 0;
    }


    /**
     * remember where the offsets will go so that we can come
     * back and record them later, if there are any channels
     * to record
     */
    context_->headerChannelOffsetLocation_ = lseek(fd, 0, SEEK_CUR);
    if (numChannels_ > 0) {
	context_->dataOffsets_ = new off_t[numChannels_];
	memset(context_->dataOffsets_, 0, numChannels_ * sizeof(off_t));

	/**
	 * skip the values for now.
	 */
	s = lseek(fd, numChannels_ * sizeof(off_t), SEEK_CUR);
	if (s < 0) {
	    setError(ERR_ERRNO);
	    return 0;
	}

    } else {
	/**
	 * leave room for one offset to pick up the
	 * beginning of the data later on
	 */
	context_->dataOffsets_ = new off_t[1];

	s = lseek(fd, sizeof(off_t), SEEK_CUR);
	if (s < 0) {
	    setError(ERR_ERRNO);
	    return 0;
	}
    }


    if ( ! storeVariableStringValue_(fd, operatorDescription_, this) )
	return 0;

    if ( ! storeVariableStringValue_(fd, subjectDescription_, this) )
	return 0;

    if ( ! storeVariableStringValue_(fd, muscleDescription_, this) )
	return 0;

    if ( ! storeVariableStringValue_(fd, generalDescription_, this) )
	return 0;


    /**
     * The information from this point on is not guaranteed to be
     * in all files, so default values must be provided
     */


    /* study flags */
    s = write(fd, &studyFlags_, sizeof(studyFlags_));
    if (s != sizeof(studyFlags_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* subject date of birth */
    s = write(fd,
	&subjectJulianDateOfBirth_,
	sizeof(subjectJulianDateOfBirth_));
    if (s != sizeof(subjectJulianDateOfBirth_)) {
	setError(ERR_ERRNO);
	return 0;
    }


    /* subject gender */
    s = write(fd, &subjectGender_, sizeof(subjectGender_));
    if (s != sizeof(subjectGender_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* muscle laterality */
    s = write(fd, &muscleSide_, sizeof(muscleSide_));
    if (s != sizeof(muscleSide_)) {
	setError(ERR_ERRNO);
	return 0;
    }

#ifndef	RESTRICT_TO_BASE_VERSION

    /* Contraction Type */
    s = write(fd, &contractionType_, sizeof(contractionType_));
    if (s != sizeof(contractionType_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* subject ID */
    if ( ! storeVariableStringValue_(fd, subjectID_, this) )
	return 0;

    /* cmapStored_ */
    s = write(fd, &cmapStored_, sizeof(cmapStored_));
    if (s != sizeof(cmapStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /* smupStored */
    s = write(fd, &mSmupStored_, sizeof(mSmupStored_));
    if (s != sizeof(mSmupStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }

    /** Simply store subject age in years */
    s = write(fd,
	&subjectAge_,
	sizeof(subjectAge_));
    if (s != sizeof(subjectAge_)) {
	setError(ERR_ERRNO);
	return 0;
	}

	/* numCmapsStored */    //ABDSAVE
    s = write(fd, &numCmapStored_, sizeof(numCmapStored_));
    if (s != sizeof(numCmapStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }

	/* numAutoSmupStored */    //mauto
    s = write(fd, &numAutoSmupStored_, sizeof(numAutoSmupStored_));
    if (s != sizeof(numAutoSmupStored_)) {
	setError(ERR_ERRNO);
	return 0;
    }

/*MarzTest*/
	s = write(fd, &indexOfFirstSmup_, sizeof(indexOfFirstSmup_)); 
	if (s != sizeof(indexOfFirstSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}

	s = write(fd, &indexOfSecondSmup_, sizeof(indexOfSecondSmup_));
	if (s != sizeof(indexOfSecondSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}

	s = write(fd, &indexOfThirdSmup_, sizeof(indexOfThirdSmup_)); 
	if (s != sizeof(indexOfThirdSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}

	s = write(fd, &indexOfBaseSmup_, sizeof(indexOfBaseSmup_)); 
	if (s != sizeof(indexOfBaseSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}
	
	s = write(fd, &FreqOfFirstSmup_, sizeof(FreqOfFirstSmup_)); 
	if (s != sizeof(FreqOfFirstSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}

	s = write(fd, &FreqOfSecondSmup_, sizeof(FreqOfSecondSmup_));
	if (s != sizeof(FreqOfSecondSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}

	s = write(fd, &FreqOfThirdSmup_, sizeof(FreqOfThirdSmup_)); 
	if (s != sizeof(FreqOfThirdSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}

	s = write(fd, &FreqOfBaseSmup_, sizeof(FreqOfBaseSmup_)); 
	if (s != sizeof(FreqOfBaseSmup_)) {
	setError(ERR_ERRNO);
	return 0;
	}
	/*MarzTest*/

    //}
#endif /* RESTRICT_TO_BASE_VERSION */

#    ifdef FORWARD_COMPAT_TEST
    if ( ! storeVariableStringValue_(fd,
	"FORWARD COMPATIBILITY TEST DATA IN HEADER",
	this) )
	return 0;
#    endif

    return 1;
}

int DQEmgData::updateContractionDataHeader_(int fd)
{
    int s;

    /**
     * get back to where we want to put the offsets
     */
    s = lseek(fd, context_->headerChannelOffsetLocation_, SEEK_SET);
    if (s < 0) {
	setError(ERR_ERRNO);
	return 0;
    }

    if (numChannels_ > 0) {

	s = write(fd, context_->dataOffsets_,
		sizeof(off_t) * numChannels_);
	if (s != (int) (sizeof(off_t) * numChannels_)) {
	    setError(ERR_ERRNO);
	    return 0;
	}

    } else {
	s = write(fd, &context_->dataOffsets_[0], sizeof(off_t));
	if (s != (int) (sizeof(off_t))) {
	    setError(ERR_ERRNO);
	    return 0;
	}
    }
    return 1;
}

int
DQEmgData::loadVariableStringValue_(
	int fd,
	char **string,
	DQEmgData *caller
    )
{
    int s;
    unsigned short length;

    s = read(fd, &length, sizeof(unsigned short));
    if (s != sizeof(unsigned short)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    if ((*string) != NULL)
	delete [] (*string);

    if (length == 0) {
	(*string) = NULL;
	return 1;
    }

    (*string) = new char[length + 1];
    (*string)[length] = 0;

    s = read(fd, (*string), length);
    if (s != length) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    return 1;
}

int
DQEmgData::storeVariableStringValue_(
	int fd,
	char *string,
	DQEmgData *caller
    )
{
    int s, l;
    unsigned short length;

    if (string != NULL)
	l = strlen(string);
    else
	l = 0;

    if (l > USHRT_MAX) {
	caller->setError(ERR_DATA_OVERFLOW);
	return 0;
    }

    length = (unsigned short) l;

    s = write(fd, &length, sizeof(unsigned short));
    if (s != sizeof(unsigned short)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    if (length != 0) {
	s = write(fd, string, length);
	if (s != l) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}
    }

    return 1;
}

int DQEmgChannelData::loadChannelData_(int fd, DQEmgData *caller)
{
    off_t firstDataOffset;
    size_t s;

    /* data offset */
    s = read(fd, &firstDataOffset, sizeof(firstDataOffset));
    if (s != sizeof(firstDataOffset)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* channel number */
    s = read(fd, &channelNumber_, sizeof(channelNumber_));
    if (s != sizeof(channelNumber_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* hipass cutoff */
    s = read(fd, &hipassCutoff_, sizeof(hipassCutoff_));
    if (s != sizeof(hipassCutoff_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
    /* lopass cutoff */
    s = read(fd, &lopassCutoff_, sizeof(lopassCutoff_));
    if (s != sizeof(lopassCutoff_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    /* encoding */
    s = read(fd, &encoding_, sizeof(short));
    if (s != sizeof(short)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* first check if we can handle this encoding */
    if (((encoding_ & 0xFF00) >> 8) != 0) {
	caller->setError(ERR_UNKNOWN_ENCODING);
	return 0;
    }


    /*
     * sampling rate -- for backwards compatibility we read
     * from a long here and cast, and then overwrite with a
     * float value if we see one later
     */
    {
	unsigned long longSamplingRate;
	s = read(fd, &longSamplingRate, sizeof(longSamplingRate));
	if (s != sizeof(longSamplingRate)) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}
	samplingRate_ = (float) longSamplingRate;
    }

    /* num samples */
    s = read(fd, &numSamples_, sizeof(numSamples_));
    if (s != sizeof(numSamples_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* elapsed time */
    s = read(fd, &elapsedTime_, sizeof(elapsedTime_));
    if (s != sizeof(elapsedTime_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* units */
    if ( ! DQEmgData::loadVariableStringValue_(
		fd,
		&unitDescription_,
		caller
	    ) )
	return 0;


    /* scale */
    s = read(fd, &scale_, sizeof(scale_));
    if (s != sizeof(scale_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    // channelDescription 
	if (version_ != 0x00) //MABD	
	{
		if ( ! DQEmgData::loadVariableStringValue_(
		fd,
		&channelDescription_,
		caller
			) )
		return 0;
	}


    /**
     * every operation from here in needs to be prefaced by this
     * so that we can read older files
     */
    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)
	goto END_OF_HEADER;


    // if ContractionType = Evoked
    if (caller->isEvoked()) {
	
		/* get negativePeakArea_ */
		s = read(fd, &negativePeakArea_, sizeof(negativePeakArea_));
		if (s != sizeof(negativePeakArea_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}

		if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
		/* get peakToPeakAmplitude */
		s = read(fd, &peakToPeakAmplitude_, sizeof(peakToPeakAmplitude_));
		if (s != sizeof(peakToPeakAmplitude_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}

		if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
		/* get negativePeakAmplitude */
		s = read(fd, &negativePeakAmplitude_, sizeof(negativePeakAmplitude_));
		if (s != sizeof(negativePeakAmplitude_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}

		if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
		/* onset position */
		s = read(fd, &onsetPos_, sizeof(onsetPos_));
		if (s != sizeof(onsetPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}

		if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
		/* positivePeak position */
		s = read(fd, &positivePeakPos_, sizeof(positivePeakPos_));
		if (s != sizeof(positivePeakPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}

		if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
		/* negativePeak position */
		s = read(fd, &negativePeakPos_, sizeof(negativePeakPos_));
		if (s != sizeof(negativePeakPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}

		if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
		/* end position */
		s = read(fd, &endPos_, sizeof(endPos_));
		if (s != sizeof(endPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
    }

	if (version_ == 0x00) //MABD
	{
		//channelDescription 
		if ( ! DQEmgData::loadVariableStringValue_(
		fd,
		&channelDescription_,
		caller
		) )
			return 0;
	}

    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
    /* isValid - added for MPS smup waveforms */
    s = read(fd, &isValid_, sizeof(isValid_));
    if (s != sizeof(isValid_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
    /* Number of Smups in the mSmup */
    s = read(fd, &numSmupsInAvg_, sizeof(numSmupsInAvg_));
    if (s != sizeof(numSmupsInAvg_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /////////// Extras for Evoked responses //////////////
    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
    /* duration_ */
    s = read(fd, &duration_, sizeof(duration_));
    if (s != sizeof(duration_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
    /* negativePeakDuration_ */
    s = read(fd, &negativePeakDuration_, sizeof(negativePeakDuration_));
    if (s != sizeof(negativePeakDuration_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
    /* area_ */
    s = read(fd, &area_, sizeof(area_));
    if (s != sizeof(area_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)	goto END_OF_HEADER;
    /* peak Onset position */
    s = read(fd, &peakOnsetPos_, sizeof(peakOnsetPos_));
    if (s != sizeof(peakOnsetPos_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)
	goto END_OF_HEADER;

    /* peak End position */
    s = read(fd, &peakEndPos_, sizeof(peakEndPos_));
    if (s != sizeof(peakEndPos_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    if (version_ != 0x00) { //MABD
	
	 if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)
	    goto END_OF_HEADER; //MABD

	/* index */
	s = read(fd, &index_, sizeof(index_));
	if (s != sizeof(index_)) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}

	/**
	 * sampling rate (again) -- if there is a floating point
	 * value for sampling rate, it will be here
	 */
	if (lseek(fd, 0, SEEK_CUR) >= firstDataOffset)
	    goto END_OF_HEADER;
	s = read(fd, &samplingRate_, sizeof(samplingRate_));
	if (s != sizeof(samplingRate_)) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}
    }

END_OF_HEADER:
    /* skip any remaining fields and go to the data */
    if ( lseek(fd, firstDataOffset, SEEK_SET) < 0) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    /**
     * read in all the data values, based on the encoding
     */
    if ((encoding_ & 0x00FF) == 2) {
	dataShortSample_ = new short[numSamples_];
	s = read(fd, dataShortSample_, numSamples_ * sizeof(short));
	if (s != (size_t) (numSamples_ * sizeof(short))) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}
	
    } else if ((encoding_ & 0x00FF) == 4) {
	dataLongSample_ = new long[numSamples_];
	s = read(fd, dataLongSample_, numSamples_ * sizeof(long));
	if (s != (size_t) (numSamples_ * sizeof(long))) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}
	
    } else {
	caller->setError(ERR_UNKNOWN_ENCODING);
	return 0;
    }

    return 1;
}

int DQEmgChannelData::storeChannelData_(int fd, DQEmgData *caller)
{
    off_t startOfHeader, startOfData = 0;
    size_t s;


    /**
     * save where we are so we can come back when we know
     * where the data will start
     */
    startOfHeader = lseek(fd, 0, SEEK_CUR);
    if (startOfHeader < 0) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* data offset */
    s = write(fd, &startOfData, sizeof(startOfData));
    if (s != sizeof(startOfData)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* channel number */
    s = write(fd, &channelNumber_, sizeof(channelNumber_));
    if (s != sizeof(channelNumber_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* hipass cutoff */
    s = write(fd, &hipassCutoff_, sizeof(hipassCutoff_));
    if (s != sizeof(hipassCutoff_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
    /* lopass cutoff */
    s = write(fd, &lopassCutoff_, sizeof(lopassCutoff_));
    if (s != sizeof(lopassCutoff_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    /* encoding */
    s = write(fd, &encoding_, sizeof(short));
    if (s != sizeof(short)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    /* sampling rate -- as a long for backwards compatibility */
    {
	unsigned long longSamplingRate;
	longSamplingRate = (unsigned long) samplingRate_;
	s = write(fd, &longSamplingRate, sizeof(longSamplingRate));
	if (s != sizeof(longSamplingRate)) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}
    }

    /* num samples */
    s = write(fd, &numSamples_, sizeof(numSamples_));
    if (s != sizeof(numSamples_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* elapsed time */
    s = write(fd, &elapsedTime_, sizeof(elapsedTime_));
    if (s != sizeof(elapsedTime_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* units */
    if ( ! DQEmgData::storeVariableStringValue_(
	fd,
	unitDescription_,
	caller
	) )
	return 0;


    /* scale */
    s = write(fd, &scale_, sizeof(scale_));
    if (s != sizeof(scale_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
	if (version_ != 0x00) //MABD
	{
		/* channelDescription */
		if ( ! DQEmgData::storeVariableStringValue_(
			fd,
			channelDescription_,
			caller
			) )
		return 0;
	}

#ifndef	RESTRICT_TO_BASE_VERSION

    /* if Contraction Type is "evoked" */
    if (caller->isEvoked()) {
		/* Negative peak area */
		s = write(fd, &negativePeakArea_, sizeof(negativePeakArea_));
		if (s != sizeof(negativePeakArea_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
		/* peak to peak amplitude*/
		s = write(fd, &peakToPeakAmplitude_, sizeof(peakToPeakAmplitude_));
		if (s != sizeof(peakToPeakAmplitude_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
		
		/* negative peak amplitude */
		s = write(fd, &negativePeakAmplitude_, sizeof(negativePeakAmplitude_));
		if (s != sizeof(negativePeakAmplitude_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
		/* onset position */
		s = write(fd, &onsetPos_, sizeof(onsetPos_));
		if (s != sizeof(onsetPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
		/* positive peak position */
		s = write(fd, &positivePeakPos_, sizeof(positivePeakPos_));
		if (s != sizeof(positivePeakPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
		/* negative peak position */
		s = write(fd, &negativePeakPos_, sizeof(negativePeakPos_));
		if (s != sizeof(negativePeakPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
		/* end position */
		s = write(fd, &endPos_, sizeof(endPos_));
		if (s != sizeof(endPos_)) {
			caller->setError(ERR_ERRNO);
			return 0;
		}
    }
	
	if (version_ == 0x00) //MABD
	{
		/* channelDescription */
		if ( ! DQEmgData::storeVariableStringValue_(
			fd,
			channelDescription_,
			caller
			) )
		return 0;
	}

    /* Store validity of SMUP waveform - added for MPS */
    s = write(fd, &isValid_, sizeof(isValid_));
    if (s != sizeof(isValid_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

    /* Number of Smups in mSmup */
    s = write(fd, &numSmupsInAvg_, sizeof(numSmupsInAvg_));
    if (s != sizeof(numSmupsInAvg_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }



    /////////// Evoked potential statistics //////////////
    s = write(fd, &duration_, sizeof(duration_));
    if (s != sizeof(duration_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
    s = write(fd, &negativePeakDuration_, sizeof(negativePeakDuration_));
    if (s != sizeof(negativePeakDuration_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
    s = write(fd, &area_, sizeof(area_));
    if (s != sizeof(area_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
    s = write(fd, &peakOnsetPos_, sizeof(peakOnsetPos_));
    if (s != sizeof(peakOnsetPos_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
    s = write(fd, &peakEndPos_, sizeof(peakEndPos_));
    if (s != sizeof(peakEndPos_)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

	
	if (version_ != 0x00) //MABD
	{
		s = write(fd, &index_, sizeof(index_)); //MABD
		if (s != sizeof(index_)) {
		caller->setError(ERR_ERRNO);
		return 0;
		}
		
		/* sampling rate as a float */
		s = write(fd, &samplingRate_, sizeof(samplingRate_));
		if (s != sizeof(samplingRate_)) {
		caller->setError(ERR_ERRNO);
		return 0;
		}
	}

#endif /* RESTRICT_TO_BASE_VERSION */

    /**
     * THIS MUST BE AFTER ALL DATA VALUES ARE STORED
     */

    /* remember where the data is about to start */
    startOfData = lseek(fd, 0, SEEK_CUR);
    if (startOfData < 0) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    /* go back and update the header offset value */
    if ( lseek(fd, startOfHeader, SEEK_SET) < 0 ) {
	caller->setError(ERR_ERRNO);
	return 0;
    }
    s = write(fd, &startOfData, sizeof(off_t));
    if (s != sizeof(off_t)) {
	caller->setError(ERR_ERRNO);
	return 0;
    }

#    ifdef FORWARD_COMPAT_TEST
    if ( ! DQEmgData::storeVariableStringValue_(
		fd,
		"-- SECOND BLOCK OF FORWARD COMPATIBILITY TEST DATA --",
		caller) )
	return 0;
#    endif

    /* now come back and actually write the data */
    if ( lseek(fd, startOfData, SEEK_SET) < 0 ) {
	caller->setError(ERR_ERRNO);
	return 0;
    }


    /* write out all the data values */
    if ((encoding_ & 0x00FF) == 2) {
	if (dataShortSample_ == NULL) {
	    if ( ! convertDataToShort_() ) {
		caller->setError(ERR_DATA_OVERFLOW);
		return 0;
	    }
	}
	s = write(fd, dataShortSample_, numSamples_ * sizeof(short));
	if (s != (size_t) (numSamples_ * sizeof(short))) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}

    } else if ((encoding_ & 0x00FF) == 4) {
	if (dataLongSample_ == NULL) {
	    if ( ! convertDataToLong_() ) {
		caller->setError(ERR_DATA_OVERFLOW);
		return 0;
	    }
	}
	s = write(fd, dataLongSample_, numSamples_ * sizeof(long));
	if (s != (size_t) (numSamples_ * sizeof(long))) {
	    caller->setError(ERR_ERRNO);
	    return 0;
	}

    } else {
	caller->setError(ERR_UNKNOWN_ENCODING);
	return 0;
    }

    return 1;
}



int DQEmgData::load_(int fd)
{
    unsigned long i;


    setError(0);
    if ( ! loadContractionDataHeader_(fd) )
	return 0;

    if (numChannels_ > 0) {
	data_ = new DQEmgChannelData *[ numChannels_ ];
	memset(data_, 0, sizeof(DQEmgChannelData *) * numChannels_);

	for (i = 0; i < numChannels_; i++) {

	    data_[i] = new DQEmgChannelData();

	    if ( lseek(fd, context_->dataOffsets_[i], SEEK_SET ) < 0) {
		setError(ERR_ERRNO);
		goto FAIL;
	    }

	    if ( ! data_[i]->loadChannelData_(fd, this) )
		goto FAIL;
	}
    } else {
	data_ = NULL;
    }

    return 1;

FAIL:
    /* clean up, and then return false */
    while (i >= 0) {
	delete data_[i];
    }
    delete [] data_;
    data_ = NULL;
    return 0;
}

int DQEmgData::store_(int fd)
{
    unsigned long i;
    DQEmgChannelData *curChannel;


    setError(0);
    if ( ! storeContractionDataHeader_(fd) )
	return 0;

    if (numChannels_ > 0) {
	for (i = 0; i < numChannels_; i++) {
	    context_->dataOffsets_[i] = lseek(fd, 0, SEEK_CUR);
	    if (context_->dataOffsets_[i] < 0) {
		setError(ERR_ERRNO);
		return 0;
	    }
	    curChannel = data_[i];
	    if ( ! curChannel->storeChannelData_(fd, this) )
		return 0;
	}
    } else {
	/**
	 * store a dummy location to the first data offset
	 * so that in cases of no channel data we can still
	 * determine how many fields we have in the file
	 */
	context_->dataOffsets_[0] = lseek(fd, 0, SEEK_CUR);
    }

    if ( ! updateContractionDataHeader_(fd) )
	return 0;

    return 1;
}


void DQEmgData::setError(int id)
{
    if (sMaxError_ < 0) {
	int i;
	for (i = 0; sErrors_[i] != NULL; i++)
	    ;
	sMaxError_ = i;
    }

    if (id >= sMaxError_) {
	fprintf(stderr, "Internal error setting errid %d\n", id);
    }

    errorId_ = id;
}

char *DQEmgData::getErrorMessage(int errid) const
{
    /* if we aren't initialized, there is no error */
    if (sMaxError_ < 0) return sErrors_[0];

    if (errid < 0 || errid >= sMaxError_)
	return "Error Number Out of Bounds";

    if (errid == 1)
	return strerror(errno);

    return sErrors_[errid];
}

int DQEmgData::getError() const
{
    return errorId_;
}

#define TAGLEN  20

void DQEmgChannelData::dump(FILE *fp)
{
    unsigned long numSamples;
    float samplingRate;
    float scale;

    fprintf(fp, "        %-*s: %d\n",
		TAGLEN, "Channel Number",
		getChannelNumber());

    fprintf(fp, "        %-*s: %ld\n",
		TAGLEN, "HighPass Cutoff",
		getHighPassCutoff());

    fprintf(fp, "        %-*s: %ld\n",
		TAGLEN, "LowPass Cutoff",
		getLowPassCutoff());

    fprintf(fp, "        %-*s: %ld\n",
		TAGLEN, "Elapsed Time",
		getElapsedTime());

    fprintf(fp, "        %-*s: [%s]\n",
		TAGLEN, "Channel Description",
		getChannelDescription());

    fprintf(fp, "        %-*s: [%s]\n",
		TAGLEN, "Units",
		getUnitDescription());

    (void) getDataAsShort(
		&numSamples,
		&samplingRate,
		&scale
	    );

    fprintf(fp, "        %-*s: %ld\n",
		TAGLEN, "Num Samples",
		numSamples);

    fprintf(fp, "        %-*s: %g\n",
		TAGLEN, "Sampling Rate",
		samplingRate);

    fprintf(fp, "        %-*s: %f\n",
		TAGLEN, "Scale",
		scale);

    fprintf(fp, "        %-*s: %f\n",
		TAGLEN, "negativePeakArea",
		getEvokedResponseNegativePeakArea());

    fprintf(fp, "        %-*s: %f\n",
		TAGLEN, "peakToPeakAmplitude",
		getEvokedResponsePeakToPeakAmplitude());

    fprintf(fp, "        %-*s: %f\n",
		TAGLEN, "negativePeakAmplitude",
		getEvokedResponseNegativePeakAmplitude());

    fprintf(fp, "        %-*s: %d\n",
		TAGLEN, "Onset Pos",
		getEvokedResponseOnsetPos());

    fprintf(fp, "        %-*s: %d\n",
		TAGLEN, "Pos-Peak Pos",
		getEvokedResponsePositivePeakPos());

    fprintf(fp, "        %-*s: %d\n",
		TAGLEN, "Neg-Peak Pos",
		getEvokedResponseNegativePeakPos());

    fprintf(fp, "        %-*s: %d\n",
		TAGLEN, "End Pos",
		getEvokedResponseEndPos());
}

void DQEmgData::dump(FILE *fp, int dumpChannelData)
{
    DQEmgChannelData *channel;
    time_t acquisitionTime;
    int gender, side, contraction;
    unsigned long year, month, day;
    unsigned char i;

    fprintf(fp, "%-*s: [%s]\n",
		TAGLEN, "Vendor",
		getVendorIdentifier());

    acquisitionTime = getAcquisitionTime();
    fprintf(fp, "%-*s: %s",
		TAGLEN, "Acquisition Time",
		ctime(&acquisitionTime));


    fprintf(fp, "%-*s: %hd\n",
		TAGLEN, "Num Channels",
		getNumChannels());


    fprintf(fp, "%-*s: [%s]\n",
		TAGLEN, "Operator",
		getOperatorDescription());

    fprintf(fp, "%-*s: [%s]\n",
		TAGLEN, "Subject Name",
		getSubjectDescription());

    if (getSubjectJulianDateOfBirth() == 0) {
	fprintf(fp, "%-*s: <unknown>\n",
		TAGLEN, "Subject D.O.B.");
    } else {
	getSubjectDateOfBirth(&year, &month, &day);
	fprintf(fp, "%-*s: %ld-%ld-%ld\n",
		TAGLEN, "Subject D.O.B.",
		day, month, year);
    }

    fprintf(fp, "%-*s: %s\n",
		TAGLEN, "Is New Operator? ",
		isNewOperator() ? "YES" : "NO");

    fprintf(fp, "%-*s: %s\n",
		TAGLEN, "Is New Patient? ",
		isNewPatient() ? "YES" : "NO");

    fprintf(fp, "%-*s: %s\n",
		TAGLEN, "Is New Muscle? ",
		isNewMuscle() ? "YES" : "NO");

    gender = getSubjectGender();
    fprintf(fp, "%-*s: %s\n",
		TAGLEN, "Subject Gender",
		(gender == 0) ? "<not recorded>" :
		    (gender == 1) ? "FEMALE" :
			(gender == 2) ? "MALE" : "ERROR");


    fprintf(fp, "%-*s: [%s]\n",
		TAGLEN, "Muscle",
		getMuscleDescription());

    side = getMuscleSide();
    fprintf(fp, "%-*s: %s\n",
		TAGLEN, "Muscle Side",
		(side == 0) ? "<not recorded>" :
		    (side == 1) ? "LEFT" :
			(side == 2) ? "RIGHT" : "ERROR");

    contraction = getContractionType();
    fprintf(fp, "%-*s: %s\n",
		TAGLEN, "Contraction Type",
		(contraction == 0) ? "<not recorded>" :
		    (contraction == 1) ? "MVC" :
			(contraction == 2) ? "Spontaneous Activity" :
			(contraction == 3) ? "Sub-Maximal" :
			(contraction == 4) ? "Evoked" :"ERROR");

    // Added for MPS
    fprintf(fp, "%-*s: [%s]\n",
		TAGLEN, "is CMAP Stored :",
		isCmapStored() ? "TRUE" : "FALSE");

    fprintf(fp, "%-*s: [%s]\n",
		TAGLEN, "is SMUP Stored :",
		is_mSmupStored() ? "TRUE" : "FALSE");

    fprintf(fp, "%-*s: [%s]\n",
		TAGLEN, "General",
		getGeneralDescription());

    if (dumpChannelData) {
	for (i = 0; i < getNumChannels(); i++) {
	    channel = getChannel(i);
	    fprintf(fp, "    %s: %d\n", "Channel", i);
	    channel->dump(fp);
	}
    }
}

/**
 ** $Log: DQEmgData.cpp,v $
 ** Revision 1.52  2006/11/09 23:26:45  andrew
 ** o Fixed no-channel header length calculation problem
 **
 ** Revision 1.51  2006/03/17 19:53:26  andrew
 ** o Changed defined limit on number of channels back to 255.
 **   This is important because the actual number of channels is stored
 **   as a char.
 ** o As the channels are now being used for other things, it is probably
 **   time to move the entire spec from v0 to v1 and update the number
 **   of channels info.  When this happens, it only makes sense to revisit
 **   the rest of the design and try and clean things up a little bit.
 **
 ** Revision 1.50  2006/03/10 13:30:10  marziye
 ** 10-18
 **
 ** Revision 1.46  2005/06/01 18:16:28  marziye
 ** o Ability to store multiple camps and select one of them for maune study
 ** o changing default study frequency to 6250
 **
 ** Revision 1.44  2004/05/10 17:51:22  andrew
 ** o Fixed test case to reflect new interface
 ** o Put back parsing of Julian DOB
 **
 ** Revision 1.43  2004/04/28 15:17:23  mahdieh
 ** == substituting Subject with Patient for consistency
 **
 ** Revision 1.42  2004/04/21 19:58:45  stashuk
 ** o update registry layout
 ** o modified studyform to use age instead of birth date
 **
 ** Revision 1.41  2004/04/12 15:00:51  stashuk
 ** o Numerous changes to April 4th
 **
 ** Revision 1.40  2004/01/29 15:56:24  andrew
 ** o Changed "sampling rate" to be a float
 **
 ** Revision 1.39  2004/01/13 16:55:30  andrew
 ** o Fixed testsuite to not dump
 **
 ** Revision 1.38  2004/01/13 16:30:38  andrew
 ** o Patient ID _should_ be recorded after contraction type, historically
 **
 ** Revision 1.37  2004/01/13 15:47:12  stashuk
 ** o Changed variable names, reformated some of the code and added some comments
 **
 ** Revision 1.36  2004/01/09 14:43:38  andrew
 ** o Added in channel test scripts -- changed addChannel to report when
 **   there are too many channels and a new channel has not been added.
 **
 ** Revision 1.35  2004/01/09 03:10:16  andrew
 ** o Added backwards compatibility test
 **
 ** Revision 1.34  2004/01/09 03:02:42  andrew
 ** o Added more test cases
 **
 ** Revision 1.33  2004/01/09 02:34:44  andrew
 ** o Cleaned up a number of things in the implementation
 **   - probe for "out of space" now performed for channel,
 **     so that older files can be read
 **   - fixed the broken ordering of several values
 ** o Changed a lot of variables names to remove contractions, etc.
 **
 ** Revision 1.32  2004/01/07 00:43:18  andrew
 ** o Fixed up some tab-damage from Charlie's code
 **
 ** Revision 1.31  2004/01/06 16:20:36  stashuk
 ** o Checking in Charlie's extensions to DQEmgData
 **
 ** Revision 1.30  2003/01/17 00:13:36  andrew
 ** o Updated DQEmgData to have "subjectId" as a field.  This will
 **   allow us to easily track unique patients in DQEMG.
 **
 ** Revision 1.29  2002/12/17 23:36:51  andrew
 ** o Took out leaky accessors
 **
 ** Revision 1.28  2002/12/03 06:19:53  yan
 ** DQEmg can get PPAmp, NPAmp & NPArea values from cmap.dat
 **
 ** Revision 1.22  2002/11/28 15:04:16  yan
 ** Fixed the DQEmgData() contractor that would otherwise
 ** cause dqemgdump and DQEmgData to crash.
 **
 ** Revision 1.21  2002/11/28 02:59:25  yan
 ** DQEmgData: added  Contraction Type
 ** DQEmgChannelData: added peak-to-peak Amplitude, Neg. peak Amplitude
 ** and Peak to peak Area.
 **
 ** AcquireEmg is ok with this version. But, its causing the
 ** dqemgdump and DQEmg to crash when opening the new version
 ** contraction.dat.
 **
 ** This will be fixed in the next version.
 **
 ** Revision 1.20  2002/09/24 13:49:50  andrew
 ** o Adding in Peter Juul's changes to the file spec.  The malloc/free
 **   based code has been re-written to be new/delete based
 ** o Also updated the vendor id code to fix a bug wrt labels of the
 **   maximum length.
 **
 ** Revision 1.19  2002/07/18 23:04:04  andrew
 ** o Regularized whitespace to spaces
 **
 ** Revision 1.18  2002/05/25 21:28:07  andrew
 ** o Working on new Muap expansion algorithm.  Marker is still
 **   misplaced; probably a +ve/-ve problem.
 **
 ** Revision 1.17  2002/05/22 15:39:45  andrew
 ** o Added in dump routines
 **
 ** Revision 1.16  2002/04/11 14:49:55  andrew
 ** o Update to pass a contraction file back to the Acquire program when
 **   it starts up.
 **
 ** Revision 1.15  2002/04/02 23:09:29  stashuk
 ** o Fixed broken "new" flag setting
 **
 ** Revision 1.14  2002/03/29 18:35:40  andrew
 ** o Added accessor for Julian format DOB
 **
 ** Revision 1.13  2002/03/29 18:32:28  andrew
 ** o Fixed bug in new-study flag sets
 **
 ** Revision 1.12  2002/03/29 17:29:27  andrew
 ** o Changed DQEmgData over to use Julian Time
 **
 ** Revision 1.11  2002/03/25 20:06:07  andrew
 ** o Changed Study Number to Study Flags
 **
 ** Revision 1.10  2002/03/23 00:58:38  andrew
 ** o Updated DQEmgData to have a better major initializer
 ** o Updated make16bit to use it
 **
 ** Revision 1.9  2002/03/23 00:10:17  andrew
 ** o Made patient study number unsigned
 ** o Updated FileFormatProposal document
 **
 ** Revision 1.8  2002/03/22 19:33:46  andrew
 ** o Updated headers to include author contact info
 **
 ** Revision 1.7  2002/03/22 19:30:18  andrew
 ** o Fixed mixup with study number
 ** o Took out unused variable
 ** o removed zipit util and made into a global tool
 **
 ** Revision 1.6  2002/03/22 18:52:37  andrew
 ** o Updated DQEmgData format to include:
 **     - patient study number
 **     - patient date of birth
 **     - patient gender
 **     - muscle side information
 **
 ** Revision 1.5  2002/03/16 21:42:56  andrew
 ** o Added "clear()" function
 **
 ** Revision 1.4  2002/03/11 22:10:42  andrew
 ** o Removed README duplicating the FileFormat document
 ** o Fixed up some type problems
 **
 ** Revision 1.3  2002/03/11 19:39:21  andrew
 ** o Updated header
 **
 ** Revision 1.2  2002/03/11 17:09:04  andrew
 ** o Updated to have floating-point data set.
 **
 ** Revision 1.1  2002/03/11 15:48:35  andrew
 ** o Initial Check-In on Public server
 ** o Cocoon Documentation Complete
 ** o Initial functionality written
 **
 **/

