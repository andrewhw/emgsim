/*-
 * Copyright (c) 2002
 * All rights reserved.
 *
 * Original Authors:
 *      Daniel Stashuk          stashuk@pami.uwaterloo.ca
 *      Andrew Hamilton-Wright  andrewhw@ieee.org
 *
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. The original authors must be made aware of, and party to, any
 *    redistribution of this source code.
 * 2. Any updates or modification to this code shall be made with
 *    the full knowledge of the original authors, so that all
 *    software using this file format may remain interoperable.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS, CONTRIBUTORS OR THE UNIVERSITY OF
 * WATERLOO BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

/**
 ** ----------------------------------------------------------------
 ** OS-dependent flag and detection code.
 **
 ** These routines will define a set of macros to identify various
 ** architectures, so that we can write more portable code.
 ** Most importantly, it will let us identify Windows, which has the
 ** most special-case code, and make it look more like the rest.
 ** ----------------------------------------------------------------
 ** - M_PI if not available
 ** - Platform path delimiters
 ** ----------------------------------------------------------------
 ** $Id: os_defs.h,v 1.4 2002/07/18 23:04:04 andrew Exp $
 **/

#ifndef __OS_DEF_TYPE_HEADER__
#define __OS_DEF_TYPE_HEADER__

/* $Id: os_defs.h,v 1.4 2002/07/18 23:04:04 andrew Exp $ */


/* System include files. */
#ifndef MAKEDEPEND
#include <stdio.h>
#endif

/* by default, try for static linkage */
#if !defined(OS_DYNAMIC) && !defined(OS_LINK_DYNAMIC) && !defined(OS_STATIC)
# define OS_STATIC
#endif

/*
 * Compilation Environment Identification
 */
#define OS_PRAGMA_ONCE
#if defined( sgi ) && defined( unix ) && !defined( cplusplus_2_1 )
#   define OS_IRIX

#elif defined( __SunOS_5_8 ) || defined( __SunOS_5_6) || defined( __SunOS_5_7 ) 
#   define OS_SOLARIS
#   define OS_SOLARIS_2_5
#   undef OS_PRAGMA_ONCE

#elif defined( __SunOS_5_5_1 ) || defined( __SunOS_5_5 )
#   define OS_SOLARIS
#   define OS_SOLARIS_2_5
#   undef OS_PRAGMA_ONCE

#elif defined( __sun ) && defined( __SVR4 )
#   define OS_SOLARIS
#   define OS_SOLARIS_2_4
#   undef OS_PRAGMA_ONCE

#elif defined( hpux )
        /* && defined( __hp9000s700 ) */
#   define OS_HPUX
#   undef OS_PRAGMA_ONCE

#elif defined( _AIX41 )
#   define OS_AIX
#   define OS_AIX_4_1

#elif defined( linux )
#   define OS_LINUX
#   undef OS_PRAGMA_ONCE

#elif defined( _WIN32 )
#   define OS_WINDOWS_NT
#   define SIMPLE_RANDOM_ONLY
#endif

#ifndef MAKEDEPEND
#include <limits.h>
#ifdef OS_WINDOWS_NT
#include <stddef.h>
#endif
#endif


#if defined( OS_IRIX )
# define OS_EXPORT
#elif defined( OS_SOLARIS_2_5 )
# define OS_EXPORT
#elif defined( OS_SOLARIS_2_4 )
# define OS_EXPORT
#elif defined( OS_HPUX )
# define OS_EXPORT
#elif defined( OS_AIX_4_1 ) 
# define OS_EXPORT
#elif defined( OS_LINUX )
# define OS_EXPORT
#elif defined( OS_WINDOWS_NT )
# if defined( OS_DYNAMIC )
#  define OS_EXPORT __declspec(dllexport)
# elif defined( OS_STATIC )
#  define OS_EXPORT
# else
#  define OS_EXPORT __declspec(dllimport)
# endif
#endif


/**
 ** Win32 hacks . . . 
 **/
#ifdef  OS_WINDOWS_NT

# include       <math.h>
# ifndef        M_PI
#  define       M_PI    3.14159265358979323846
# endif

#define random()        rand()
#define srandom()       srand()

typedef int             mode_t;
typedef int             pid_t;

# define        OS_PATH_DELIM                   '\\'
# define        OS_PATH_DELIM_STRING            "\\"
# define        OS_PATH_INVALID_DELIM           '/'
# define        OS_PATH_INVALID_DELIM_STRING    "/"
#else
# define        OS_PATH_DELIM                   '/'
# define        OS_PATH_DELIM_STRING            "/"
# define        OS_PATH_INVALID_DELIM           '\\'
# define        OS_PATH_INVALID_DELIM_STRING    "\\"
#endif


# ifdef OS_PRAGMA_ONCE
#  pragma once
# endif

#endif /* !OS_DEF_TYPE_HEADER */


/**
 ** $Log: os_defs.h,v $
 ** Revision 1.4  2002/07/18 23:04:04  andrew
 ** o Regularized whitespace to spaces
 **
 ** Revision 1.3  2002/03/22 19:33:46  andrew
 ** o Updated headers to include author contact info
 **
 ** Revision 1.2  2002/03/22 18:52:37  andrew
 ** o Updated DQEmgData format to include:
 **     - patient study number
 **     - patient date of birth
 **     - patient gender
 **     - muscle side information
 **
 ** Revision 1.1  2002/03/11 15:48:35  andrew
 ** o Initial Check-In on Public server
 ** o Cocoon Documentation Complete
 ** o Initial functionality written
 **
 **/

